import React, { useState } from "react";
import { styled } from "@mui/material/styles";
import MuiDrawer from "@mui/material/Drawer";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import List from "@mui/material/List";
import { Box, Collapse, Divider } from "@mui/material";
import { hasChildren } from "../../Helper/utils";
import { menu } from "../../Routes/routes";
import HttpIcon from "@mui/icons-material/Http";

const Sidebar = ({ drawerWidth, open }) => {
  const MultiLevel = ({ item }) => {
    const { items: children } = item;
    const [openDrop, setOpenDrop] = useState(false);

    const handleClick = () => {
      setOpenDrop((prev) => !prev);
    };

    return (
      <React.Fragment>
        <Box
          sx={{
            opacity: "1",
            background: "transparent",
            color: "rgb(255, 255, 255)",
            display: "flex",
            WebkitBoxAlign: "center",
            alignItems: "center",
            width: "100%",
            borderRadius: "0.375rem",
            cursor: "pointer",
            userSelect: "none",
            whiteSpace: "nowrap",
            boxShadow: "none",
          }}
        >
          <ListItem
            button
            onClick={handleClick}
            disablePadding
            sx={{ display: "block" }}
          >
            <ListItemButton
              sx={{
                minHeight: 48,
                justifyContent: open ? "initial" : "center",
                px: 2.5,
              }}
            >
              <ListItemIcon
                sx={{
                  mr: open ? 3 : "auto",
                  justifyContent: "center",
                  flexShrink: 0,
                  minWidth: "2rem",
                  minHeight: "2rem",
                  marginRight: "13px !important",
                  color: "rgb(255, 255, 255)",
                  borderRadius: "0.375rem",
                  display: "flex",
                  placeItems: "center",
                  transition: "margin 300ms cubic-bezier(0.4, 0, 0.2, 1) 0ms",
                }}
              >
                {item.icon}
              </ListItemIcon>
              <ListItemText
                primary={item.title}
                primaryTypographyProps={{
                  style: {
                    fontSize: "0.875rem",
                    fontWeight: 400,
                    lineHeight: 0,
                  },
                }}
                sx={{ opacity: open ? 1 : 0 }}
              />
              {open ? openDrop ? <ExpandLessIcon /> : <ExpandMoreIcon /> : ""}
            </ListItemButton>
          </ListItem>
        </Box>
        <Collapse in={openDrop} timeout="auto" unmountOnExit>
          <List component="div" disablePadding>
            {children.map((child, key) => (
              <MenuItem key={key} item={child} />
            ))}
          </List>
        </Collapse>
      </React.Fragment>
    );
  };

  const MenuItem = ({ item }) => {
    const Component = hasChildren(item) ? MultiLevel : SingleLevel;
    return <Component item={item} />;
  };

  const SingleLevel = ({ item }) => {
    return (
      <Box
        sx={{
          opacity: "1",
          background: "transparent",
          color: "rgb(255, 255, 255)",
          display: "flex",
          WebkitBoxAlign: "center",
          alignItems: "center",
          width: "100%",
          borderRadius: "0.375rem",
          cursor: "pointer",
          userSelect: "none",
          whiteSpace: "nowrap",
          boxShadow: "none",
        }}
      >
        <ListItem button disablePadding sx={{ display: "block" }}>
          <ListItemButton
            sx={{
              minHeight: 48,
              justifyContent: open ? "initial" : "center",
              px: 2.5,
            }}
          >
            <ListItemIcon
              sx={{
                mr: open ? 3 : "auto",
                justifyContent: "center",
                flexShrink: 0,
                minWidth: "2rem",
                minHeight: "2rem",
                marginRight: "13px !important",
                color: "rgb(255, 255, 255)",
                borderRadius: "0.375rem",
                display: "grid",
                placeItems: "center",
                transition: "margin 300ms cubic-bezier(0.4, 0, 0.2, 1) 0ms",
              }}
            >
              {item.icon}
            </ListItemIcon>
            <ListItemText
              primary={item.title}
              primaryTypographyProps={{
                style: {
                  fontSize: "0.875rem",
                  fontWeight: 400,
                  lineHeight: 0,
                },
              }}
              sx={{ opacity: open ? 1 : 0 }}
            />
          </ListItemButton>
        </ListItem>
      </Box>
    );
  };

  const openedMixin = (theme) => ({
    width: drawerWidth,
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
    overflowX: "hidden",
  });

  const closedMixin = (theme) => ({
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    overflowX: "hidden",
    width: `calc(${theme.spacing(7)} + 1px)`,
    [theme.breakpoints.up("sm")]: {
      width: `calc(${theme.spacing(8)} + 1px)`,
    },
  });

  const DrawerHeader = styled("div")(({ theme }) => ({
    display: "flex",
    alignItems: "center",
    padding: theme.spacing(0, 1),
    // necessary for content to be below app bar
    ...theme.mixins.toolbar,
  }));

  const Drawer = styled(MuiDrawer, {
    shouldForwardProp: (prop) => prop !== "open",
  })(({ theme, open }) => ({
    width: drawerWidth,
    flexShrink: 0,
    whiteSpace: "nowrap",
    boxSizing: "border-box",

    ...(open && {
      ...openedMixin(theme),
      "& .MuiDrawer-paper": openedMixin(theme),
    }),
    ...(!open && {
      ...closedMixin(theme),
      "& .MuiDrawer-paper": closedMixin(theme),
    }),
  }));

  return (
    <>
      <Drawer
        variant="permanent"
        elevation={10}
        open={open}
        
        PaperProps={{
          sx: {
            boxShadow: "rgb(0 0 0 / 5%) 0rem 1.25rem 1.6875rem 0rem !important",
            marginBottom: "inherit !important",

            transition:
              "width 225ms cubic-bezier(0.4, 0, 0.6, 1) 0ms, background-color 225ms cubic-bezier(0.4, 0, 0.6, 1) 0ms !important",
            border: "none !important",
            background:
              "linear-gradient(195deg, rgb(66, 66, 74), rgb(25, 25, 25)) !important",
            overflowY: "scroll !important",
            display: "flex !important",
            flexDirection: "column !important",
            flex: "1 0 auto !important",
            zIndex: "1200 !important",
            position: "fixed !important",
            top: "0px !important",
            outline: "0px !important",
            height: "calc(100vh - 2rem) !important",
            margin: "1rem",
            borderRadius: "0.75rem",
          },
        }}
      >
        <DrawerHeader>
          <Box
            sx={{
              opacity: "1",
              background: "transparent",
              color: "rgb(255, 255, 255)",
              display: "flex",
              WebkitBoxAlign: "center",
              alignItems: "center",
              width: "100%",
              borderRadius: "0.375rem",
              cursor: "pointer",
              userSelect: "none",
              whiteSpace: "nowrap",
              boxShadow: "none",
            }}
          >
            <ListItem button disablePadding sx={{ display: "block" }}>
              <ListItemButton
                sx={{
                  minHeight: 48,
                  justifyContent: open ? "initial" : "center",
                  px: 2.5,
                }}
              >
                <ListItemIcon
                  sx={{
                    mr: open ? 3 : "auto",
                    justifyContent: "center",
                    flexShrink: 0,
                    minWidth: "2rem",
                    minHeight: "2rem",
                    marginRight: "13px !important",
                    color: "rgb(255, 255, 255)",
                    borderRadius: "0.375rem",
                    display: "grid",
                    placeItems: "center",
                    transition: "margin 300ms cubic-bezier(0.4, 0, 0.2, 1) 0ms",
                  }}
                >
                  <HttpIcon />
                </ListItemIcon>
                <ListItemText
                  primary="Mui Test Dashboard"
                  primaryTypographyProps={{
                    style: {
                      fontSize: "0.875rem",
                      fontWeight: 400,
                      lineHeight: 0,
                    },
                  }}
                  sx={{ opacity: open ? 1 : 0 }}
                />
              </ListItemButton>
            </ListItem>
          </Box>
        </DrawerHeader>
        <Divider
          variant="middle"
          sx={{
            borderColor: "white",
          }}
        />
        <List>
          {menu.map((item, key) => (
            <MenuItem key={key} item={item} />
          ))}
        </List>
      </Drawer>
    </>
  );
};

export default Sidebar;
