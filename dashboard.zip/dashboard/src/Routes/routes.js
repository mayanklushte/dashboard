import DashboardIcon from '@mui/icons-material/Dashboard';
import LocalLibraryIcon from "@mui/icons-material/LocalLibrary";
import TrendingUpIcon from "@mui/icons-material/TrendingUp";
import DescriptionIcon from "@mui/icons-material/Description";
import React from "react";

export const menu = [
  {
    icon: <DashboardIcon />,
    title: "Dashboard",
    items: [],
  },
  {
    icon: <LocalLibraryIcon />,
    title: "Education",
    items: [
      {
        title: "Technical",
        items: [
          {
            title: "The Dow",
            to: "/thedowtheory",
          },
          {
            title: "Charts",
            to: "/chart",
          },
          {
            title: "Trend",
            to: "/trendlines",
          },
          {
            title: "Support ",
            to: "/sandr",
          },
        ],
      },
      {
        title: "Fundamental",
        items: [
          {
            title: "The Dow",
            to: "/thedowtheory",
          },
          {
            title: "Charts",
            to: "/chart",
          },
          {
            title: "Trend",
            to: "/trendlines",
          },
          {
            title: "Support",
            to: "/sandr",
          },
        ],
      },
      {
        title: "Elliot",
        items: [
          {
            title: "The Dow",
            to: "/thedowtheory",
          },
          {
            title: "Charts",
            to: "/chart",
          },
          {
            title: "Trend",
            to: "/trendlines",
          },
          {
            title: "Support",
            to: "/sandr",
          },
        ],
      },
    ],
  },
  {
    icon: <TrendingUpIcon />,
    title: "Options",
  },
  {
    icon: <DescriptionIcon />,
    title: "Blog",
  },
  {
    icon: <DashboardIcon />,
    title: "Dashboard",
    items: [],
  },
  {
    icon: <LocalLibraryIcon />,
    title: "Education",
    items: [
      {
        title: "Technical",
        items: [
          {
            title: "The Dow",
            to: "/thedowtheory",
          },
          {
            title: "Charts",
            to: "/chart",
          },
          {
            title: "Trend",
            to: "/trendlines",
          },
          {
            title: "Support ",
            to: "/sandr",
          },
        ],
      },
      {
        title: "Fundamental",
        items: [
          {
            title: "The Dow",
            to: "/thedowtheory",
          },
          {
            title: "Charts",
            to: "/chart",
          },
          {
            title: "Trend",
            to: "/trendlines",
          },
          {
            title: "Support",
            to: "/sandr",
          },
        ],
      },
      {
        title: "Elliot",
        items: [
          {
            title: "The Dow",
            to: "/thedowtheory",
          },
          {
            title: "Charts",
            to: "/chart",
          },
          {
            title: "Trend",
            to: "/trendlines",
          },
          {
            title: "Support",
            to: "/sandr",
          },
        ],
      },
    ],
  },
  {
    icon: <TrendingUpIcon />,
    title: "Options",
  },
  {
    icon: <DescriptionIcon />,
    title: "Blog",
  },
  {
    icon: <DashboardIcon />,
    title: "Dashboard",
    items: [],
  },
  {
    icon: <LocalLibraryIcon />,
    title: "Education",
    items: [
      {
        title: "Technical",
        items: [
          {
            title: "The Dow",
            to: "/thedowtheory",
          },
          {
            title: "Charts",
            to: "/chart",
          },
          {
            title: "Trend",
            to: "/trendlines",
          },
          {
            title: "Support ",
            to: "/sandr",
          },
        ],
      },
      {
        title: "Fundamental",
        items: [
          {
            title: "The Dow",
            to: "/thedowtheory",
          },
          {
            title: "Charts",
            to: "/chart",
          },
          {
            title: "Trend",
            to: "/trendlines",
          },
          {
            title: "Support",
            to: "/sandr",
          },
        ],
      },
      {
        title: "Elliot",
        items: [
          {
            title: "The Dow",
            to: "/thedowtheory",
          },
          {
            title: "Charts",
            to: "/chart",
          },
          {
            title: "Trend",
            to: "/trendlines",
          },
          {
            title: "Support",
            to: "/sandr",
          },
        ],
      },
    ],
  },
  {
    icon: <TrendingUpIcon />,
    title: "Options",
  },
  {
    icon: <DescriptionIcon />,
    title: "Blog",
  },
  {
    icon: <DashboardIcon />,
    title: "Dashboard",
    items: [],
  },
  {
    icon: <LocalLibraryIcon />,
    title: "Education",
    items: [
      {
        title: "Technical",
        items: [
          {
            title: "The Dow",
            to: "/thedowtheory",
          },
          {
            title: "Charts",
            to: "/chart",
          },
          {
            title: "Trend",
            to: "/trendlines",
          },
          {
            title: "Support ",
            to: "/sandr",
          },
        ],
      },
      {
        title: "Fundamental",
        items: [
          {
            title: "The Dow",
            to: "/thedowtheory",
          },
          {
            title: "Charts",
            to: "/chart",
          },
          {
            title: "Trend",
            to: "/trendlines",
          },
          {
            title: "Support",
            to: "/sandr",
          },
        ],
      },
      {
        title: "Elliot",
        items: [
          {
            title: "The Dow",
            to: "/thedowtheory",
          },
          {
            title: "Charts",
            to: "/chart",
          },
          {
            title: "Trend",
            to: "/trendlines",
          },
          {
            title: "Support",
            to: "/sandr",
          },
        ],
      },
    ],
  },
  {
    icon: <TrendingUpIcon />,
    title: "Options",
  },
  {
    icon: <DescriptionIcon />,
    title: "Blog",
  },
  
];
