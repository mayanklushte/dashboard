import React from 'react'
import DashboardLayout from '../../Layouts/DashboardLayout'


const Forms = () => {
  return (
    <DashboardLayout>
        
    </DashboardLayout>
  )
}

export default Forms