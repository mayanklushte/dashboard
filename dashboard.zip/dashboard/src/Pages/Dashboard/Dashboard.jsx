import React from "react";
import DashboardLayout from "../../Layouts/DashboardLayout";
import Grid from "@mui/material/Grid";

const Dashboard = () => {
  return (
    <DashboardLayout>
      
    </DashboardLayout>
  );
};

export default Dashboard;
