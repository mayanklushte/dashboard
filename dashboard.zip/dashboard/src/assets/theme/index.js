import { createTheme } from "@mui/material/styles";
import colors from "./base/colors";
import typography from "./base/typography";
import globals from "./base/globals";
import button from "./components/Button";
import card from "./components/card";
import cardMedia from "./components/card/cardMedia";
import cardContent from "./components/card/cardContent";
import list from "./components/list";
import menu from "./components/menu";
import menuItem from "./components/menu/menuItem";
import cardHeader from "./components/card/cardHeader";
import pxToRem from "./functions/pxToRem";

export default createTheme({
  palette: { ...colors },
  typography: { ...typography },
  function: {
    pxToRem,
  },

  components: {
    MuiCssBaseline: {
      styleOverrides: {
        ...globals,
      },
    },
    MuiButton: { ...button },
    MuiCard: { ...card },
    MuiCardMedia: { ...cardMedia },
    MuiCardContent: { ...cardContent },
    MuiCardHeader: { ...cardHeader },

    MuiList: { ...list },
    MuiMenu: { ...menu },
    MuiMenuItem: { ...menuItem },
  },
});
