const outlined = {
  base: {
    boxShadow: "0 0 10px rgba(0, 0, 0, 0.1)",

    "&:hover": {
      boxShadow: "0 0 5px rgba(0, 0, 0, 0.5)",
    },
  }
};

export default outlined;
