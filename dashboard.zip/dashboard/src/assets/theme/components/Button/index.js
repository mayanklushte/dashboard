import root from "./root";
import contained from "./contained";
import outlined from "./outlined";

const button = {
  defaultProps: {
    disableRipple: false,
  },
  styleOverrides: {
    root: {
      ...root,
    },
    contained: { ...contained.base },
    outlined: { ...outlined.base },
  },
};

export default button;
