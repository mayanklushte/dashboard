import pxToRem from "../../functions/pxToRem";

const root = {
  display: "inline-flex",
  justifyContent: "center",
  alignItems: "center",
  fontSize: pxToRem(12),
  fontWeight: "700",
  width: "auto",
  padding: `${pxToRem(6)} ${pxToRem(12)}`,
  lineHeight: 1.4,
  textAlign: "center",
  textDecoration: "none",
  textTransform: "uppercase",
  borderRadius: pxToRem(8),
  margin: `${pxToRem(5)} ${pxToRem(5)}`,
  backgroundSize: "150% !important",
  backgroundPositionX: "25% !important",
  transition: "all 150ms ease-in",
  cursor: "pointer",

  "&:disabled": {
    pointerEvent: "none",
    opacity: 0.65,
  },

  "& .MuiSvgIcon-root": {
    fontSize: pxToRem(15),
    marginTop: pxToRem(-2),
  },
};

export default root;
