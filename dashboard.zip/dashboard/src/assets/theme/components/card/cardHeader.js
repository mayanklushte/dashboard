const cardHeader = {
  styleOverrides: {
    root: {
      padding: "0.5rem 1rem",
      marginBottom: 0,
      
    },
  },
};

export default cardHeader;
