import colors from "../../base/colors";
import pxToRem from "../../functions/pxToRem";
import rgba from "../../functions/rgba";

const { black, white } = colors;

const card = {
  styleOverrides: {
    root: {
      display: "flex",
      flexDirection: "column",
      position: "relative",
      wordWrap: "break-word",
      minWidth: 0,
      backgroundColor: white.main,
      backgroundClip: "border-box",
      border: `${pxToRem(1)} solid ${rgba(black.main, 0.125)}`,
      boxShadow:
        "rgb(0 0 0 / 20%) 0px 2px 1px -1px, rgb(0 0 0 / 14%) 0px 1px 1px 0px, rgb(0 0 0 / 12%) 0px 1px 3px 0px;",
      overflow: "visible",
      borderRadius: "calc(0.25rem - 1px)",
    },
  },
};

export default card;
