import colors from "../../base/colors";

import pxToRem from "../../functions/pxToRem";

const { text, white } = colors;

const menu = {
  defaultProps: {
    disableAutoFocusItem: true,
  },

  styleOverrides: {
    paper: {
      minWidth: pxToRem(160),
      boxShadow:
        "rgb(0 0 0 / 20%) 0px 2px 1px -1px, rgb(0 0 0 / 14%) 0px 1px 1px 0px, rgb(0 0 0 / 12%) 0px 1px 3px 0px;",
      padding: `${pxToRem(16)} ${pxToRem(8)}`,
      fontSize: pxToRem(12),
      color: text.main,
      textAlign: "left",
      backgroundColor: `${white.main} !important`,
      borderRadius: pxToRem(6),
    },
  },
};

export default menu;
