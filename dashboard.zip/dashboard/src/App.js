import { Button, ThemeProvider } from "@mui/material";
import "./App.css";
import theme from "./assets/theme";

function App() {
  return (
    <ThemeProvider theme={theme}>
      <div className="App">
        Hello Apps
        <Button variant="text">Text</Button>
        <Button variant="contained">Contained</Button>
        <Button variant="outlined">Outlined</Button>
      </div>
    </ThemeProvider>
  );
}

export default App;
