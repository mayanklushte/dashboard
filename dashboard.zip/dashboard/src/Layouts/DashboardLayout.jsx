import { Box } from '@mui/material'
import React from 'react'
import Header from '../Components/Header/Header'
import Sidebar from '../Components/Sidebar/Sidebar'


const drawerWidth = 240;

const DashboardLayout = (props) => {
const [open, setOpen] = React.useState(true);

const handleDrawerOpen = () => {
    setOpen(true);
  };

  const handleDrawerClose = () => {
    setOpen(false);
  };
  return (
    <Box sx={{ display: 'flex' }}>
        
        <Sidebar open={open} drawerWidth={drawerWidth} />
        
        <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
        <Header open={open} drawerWidth={drawerWidth} handleDrawerOpen={handleDrawerOpen} handleDrawerClose={handleDrawerClose}/>
        {props.children}
        </Box>
        

    </Box>
  )
}

export default DashboardLayout